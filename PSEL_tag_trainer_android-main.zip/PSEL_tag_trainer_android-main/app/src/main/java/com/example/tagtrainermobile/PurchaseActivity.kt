package com.example.tagtrainermobile

import android.content.Intent
import android.os.Bundle
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.tagtrainermobile.models.Product
import com.example.tagtrainermobile.models.cartProductsAdapter
import java.text.DecimalFormat
import android.os.Bundle;
import com.google.firebase.analytics.FirebaseAnalytics;
import androidx.appcompat.app.AppCompatActivity;

class PurchaseActivity : AppCompatActivity() {

    var cartProducts = Product.SingleCart.singleCartinstance

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(R.style.Theme_TagTrainerMobile)
        setContentView(R.layout.activity_purchase)
        cartTotalPrice()
        setRandomTransactionCode()
        setTransactionInfo()
        setProgressBar()
        displayPurchaseItems()
    }

    fun cartTotalPrice() : Double {
        var totalValue: Double = 0.0
        val totalQuantity: Int = 0
        for (i in cartProducts.indices) {
            cartProducts.get(i).quantity
            totalValue = totalValue + cartProducts.get(i).price

        }
        return totalValue
    }

    fun setRandomTransactionCode() : String {
        val numbers = (0..40103430).random()
        val character = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        val randChar = character.random()
        return numbers.toString()+randChar
    }

    fun setTransactionInfo() {
        val df = DecimalFormat("#.00")
        val txtTransactioId = findViewById<TextView>(R.id.transactioId)
            txtTransactioId.text = "Sua Compra: "+setRandomTransactionCode()
        val txtTransactionTotal = findViewById<TextView>(R.id.transactioTotalId)
            txtTransactionTotal.text = "Total: R$ "+df.format(cartTotalPrice())
    }

    fun setProgressBar() {
        val progressBar = findViewById<ProgressBar>(R.id.progressBar2)
            progressBar.progress = 100
    }

    fun displayPurchaseItems() {
        val purchaseTable = findViewById<ListView>(R.id.diplayPurchaseId)
        val adapter = cartProductsAdapter(this, cartProducts)
            purchaseTable.adapter = adapter
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
    }

}

public class AnalyticsActivity extends AppCompatActivity {

    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analytics);

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        logAppOpenEvent();
        logPurchaseEvent("12345", "Produto Exemplo", 29.99);
        logViewItemEvent("98765", "Produto Visualizado");
        logAddToCartEvent("98765", "Produto Adicionado ao Carrinho");
        logBeginCheckoutEvent(59.98);
        logSearchEvent("termo de busca");
    }

    private void logAppOpenEvent() {
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.APP_OPEN, null);
    }

    private void logPurchaseEvent(String itemId, String itemName, double value) {
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_ID, itemId);
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, itemName);
        bundle.putDouble(FirebaseAnalytics.Param.VALUE, value);
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.PURCHASE, bundle);
    }

    private void logViewItemEvent(String itemId, String itemName) {
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_ID, itemId);
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, itemName);
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.VIEW_ITEM, bundle);
    }

    private void logAddToCartEvent(String itemId, String itemName) {
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_ID, itemId);
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, itemName);
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.ADD_TO_CART, bundle);
    }
    private void logBeginCheckoutEvent(double cartValue) {
        Bundle bundle = new Bundle();
        bundle.putDouble(FirebaseAnalytics.Param.VALUE, cartValue);
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.BEGIN_CHECKOUT, bundle);
    
    private void logSearchEvent(String searchTerm) {
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.SEARCH_TERM, searchTerm);
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SEARCH, bundle);
    }
}
