package com.example.tagtrainermobile

import android.app.SearchManager
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.tagtrainermobile.models.ListProductsAdapter
import com.example.tagtrainermobile.models.ListingProduct
import android.os.Bundle;
import com.google.firebase.analytics.FirebaseAnalytics;
import androidx.appcompat.app.AppCompatActivity;

var listingProducts = ListingProduct.SingleList.singleListInstance
var searchedItens = ArrayList<ListingProduct>()


class SearchableActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(R.style.Theme_TagTrainerMobile)
        setContentView(R.layout.activity_searchable)
        searchedItens.clear()

        if (Intent.ACTION_SEARCH == intent.action) {
            intent.getStringExtra(SearchManager.QUERY)?.also { query ->
            doMySearch(query)
                setSearcheableConfiguration(query)
            }
        }
    }

    fun onClickedProducts(v: ListView, p: Int) {
        val intent = Intent(applicationContext, ProductActivity::class.java)

        val params = Bundle()
        params.putInt("id", p-1)
        intent.putExtras(params)

        startActivity(intent)
    }

    fun doMySearch(query : String) : ArrayList<ListingProduct>? {
        val allSearchProducts = ArrayList<ListingProduct>()
        for (List in listingProducts) {
            if (List.listProdId.toString() == query) {
                allSearchProducts.add(List)
            } else if (List.listProdName.contains(query, ignoreCase = true)) {
                allSearchProducts.add(List)
            } else if (List.listProdDesc.contains(query, ignoreCase = true)) {
                allSearchProducts.add(List)
            }
        }
        return allSearchProducts
    }

    fun setSearcheableConfiguration(query : String) {
        val searchResult = findViewById<TextView>(R.id.searchResultsId)
            searchResult.text = "Resultado de Busca: "+query
        val searchTable = findViewById<ListView>(R.id.tableResultsId)
        val productResult = doMySearch(query)
        if (productResult?.size!! > 0) {
            val adapter = ListProductsAdapter(this, productResult)
            searchTable.adapter = adapter
            searchTable.setOnItemClickListener { parent, view, position, id ->
                onClickedProducts(searchTable, productResult.get(position).listProdId)
            }

        } else {
            val prodNotFoundId = findViewById<TextView>(R.id.prodNotFoundId)
                prodNotFoundId.visibility = View.VISIBLE
                prodNotFoundId.text = "Ops!! Produto não Encontrado!!"
        }

    }
}

public class AnalyticsActivity extends AppCompatActivity {

    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analytics);

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        logAppOpenEvent();
        logPurchaseEvent("12345", "Produto Exemplo", 29.99);
        logViewItemEvent("98765", "Produto Visualizado");
        logAddToCartEvent("98765", "Produto Adicionado ao Carrinho");
        logBeginCheckoutEvent(59.98);
        logSearchEvent("termo de busca");
    }

    private void logAppOpenEvent() {
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.APP_OPEN, null);
    }

    private void logPurchaseEvent(String itemId, String itemName, double value) {
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_ID, itemId);
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, itemName);
        bundle.putDouble(FirebaseAnalytics.Param.VALUE, value);
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.PURCHASE, bundle);
    }

    private void logViewItemEvent(String itemId, String itemName) {
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_ID, itemId);
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, itemName);
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.VIEW_ITEM, bundle);
    }

    private void logAddToCartEvent(String itemId, String itemName) {
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_ID, itemId);
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, itemName);
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.ADD_TO_CART, bundle);
    }
    private void logBeginCheckoutEvent(double cartValue) {
        Bundle bundle = new Bundle();
        bundle.putDouble(FirebaseAnalytics.Param.VALUE, cartValue);
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.BEGIN_CHECKOUT, bundle);
    
    private void logSearchEvent(String searchTerm) {
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.SEARCH_TERM, searchTerm);
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SEARCH, bundle);
    }
}
